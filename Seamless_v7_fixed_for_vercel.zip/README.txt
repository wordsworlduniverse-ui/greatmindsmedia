Seamless v7 fixed package for Vercel

This ZIP contains index.html at the root plus logo.png and README.

Upload this ZIP to Vercel (New Project → Import from → Upload) and it should detect index.html.
